A Pen created at CodePen.io. You can find this one at https://codepen.io/apenshar/pen/rGxvwP.

 https://dribbble.com/shots/1896476-Retro-Clock?list=users&offset=7